from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.base_hook import BaseHook
from datetime import datetime, timedelta
from supabase import create_client, Client
import pandas as pd
import os
import json

default_args = {
    'owner': 'hamza',
    'depends_on_past': False,
    'start_date': datetime(2024, 7, 9),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def process_csv(file_path, fname):
    df = pd.read_csv(file_path, header=None, names=["singer", "title", "album", "date"])
    df['singer'] = df['singer'].astype(str)
    df['album'] = df['album'].astype(str)
    df['title'] = df['title'].astype(str)
    df['date'] = df['date'].astype(str)

    df['date'] = pd.to_datetime(df['date'], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')

    df['fname'] = fname

    print(f"the file :{fname} has been processed successfully")
    return df


def process_ingestion_task():
    folder_path = "/home/hamza/airflow/dags/Lastfm" #path containing all csv files
    csv_files = [f for f in os.listdir(folder_path) if f.endswith(".csv")]
    i = 0
    for csv_file in csv_files:
        file_path = os.path.join(folder_path,csv_file)
        df = process_csv(file_path, csv_file)
        df_json = df.to_json(orient = 'records', date_format = 'iso')
        insert_data_supabase(df_json)
        print(f"the file : {csv_file} has been well inserted")
        i +=1
        print(i)
    
    return 0


def insert_data_supabase(df_json):
    try:
        #using 100000 batch because it timesout if there is more than 100000 rows to insert at once
        batch_size = 100000
        df_json = json.loads(df_json)
        supabase_conn = BaseHook.get_connection('supabase_music_viz')
        # Connect to Supabase
        supabase_url = supabase_conn.host #in my airflow connections
        supabase_key = supabase_conn.password #in my airflow connections
        supabase : Client = create_client(supabase_url, supabase_key)
        print("start inserting file") 
        for i in range(0, len(df_json), batch_size):
            batch = df_json[i:i + batch_size]
            response = supabase.table('flow_in_music_data').insert(batch).execute()
        #print(response)
    except Exception as e :
        print(f"erreur dans l'insertion {str(e)}")



with DAG('flow_in_supabase_music_data',
         default_args=default_args,
         schedule_interval=None,
         catchup=False) as dag:

    insertion_task = PythonOperator(
        task_id = 'insertion_data',
        python_callable= process_ingestion_task
    )
    insertion_task
